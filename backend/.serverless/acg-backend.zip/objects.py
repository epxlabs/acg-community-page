mentorData = {'epx1@hotmail.com':{
"name": ["EPX engineer #4"],
"interests": ["Women in engineering", "teaching", "aws"],
"certs": ["DDB", "S3", "Lambda", "Cognito", "security"],
"skills": ["trout", "salmon", "cod"],
"location": ["Las Vegas"]
},
'epx2@hotmail.com':{
"name": ["EPX engineer #2"],
"interests": ["Women in engineering", "teaching", "aws"],
"certs": ["DDB", "S3", "Lambda", "Cognito", "security"],
"skills": ["fishing", "ddb", "running"],
"location": ["Las Vegas"]
},
'epx3@hotmail.com':{
"name": ["EPX engineer #7"],
"interests": ["Women in engineering", "teaching", "aws"],
"certs": ["DDB", "S3", "Lambda", "Cognito", "security"],
"skills": ["aws", "ddb", "s3"],
"location": ["Las Vegas"]
}
}
businessData = {'skills':['aws', 'ddb', 's3'],
'certs': ['DDB', "Lambda", "Cognito"]}
